--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Accor";
--
-- Name: Accor; Type: DATABASE; Schema: -; Owner: ngd_master_user
--

CREATE DATABASE "Accor" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "Accor" OWNER TO ngd_master_user;

\connect "Accor"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent; Type: TABLE; Schema: public; Owner: ngd_master_user
--

CREATE TABLE public.agent (
    id integer NOT NULL,
    "emailAddress" character varying NOT NULL,
    "firstName" character varying,
    "lastName" character varying,
    "groupcroId" integer
);


ALTER TABLE public.agent OWNER TO ngd_master_user;

--
-- Name: agent_id_seq; Type: SEQUENCE; Schema: public; Owner: ngd_master_user
--

CREATE SEQUENCE public.agent_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_id_seq OWNER TO ngd_master_user;

--
-- Name: agent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ngd_master_user
--

ALTER SEQUENCE public.agent_id_seq OWNED BY public.agent.id;


--
-- Name: agent_maincro_id_seq; Type: SEQUENCE; Schema: public; Owner: ngd_master_user
--

CREATE SEQUENCE public.agent_maincro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_maincro_id_seq OWNER TO ngd_master_user;

--
-- Name: agent_subcro_id_seq; Type: SEQUENCE; Schema: public; Owner: ngd_master_user
--

CREATE SEQUENCE public.agent_subcro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_subcro_id_seq OWNER TO ngd_master_user;

--
-- Name: agent_subcro; Type: TABLE; Schema: public; Owner: ngd_master_user
--

CREATE TABLE public.agent_subcro (
    id integer DEFAULT nextval('public.agent_subcro_id_seq'::regclass) NOT NULL,
    "agentId" integer NOT NULL,
    "maincroSubcroId" integer NOT NULL
);


ALTER TABLE public.agent_subcro OWNER TO ngd_master_user;

--
-- Name: groupcro_id_seq; Type: SEQUENCE; Schema: public; Owner: ngd_master_user
--

CREATE SEQUENCE public.groupcro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.groupcro_id_seq OWNER TO ngd_master_user;

--
-- Name: groupCro; Type: TABLE; Schema: public; Owner: ngd_master_user
--

CREATE TABLE public."groupCro" (
    id integer DEFAULT nextval('public.groupcro_id_seq'::regclass) NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public."groupCro" OWNER TO ngd_master_user;

--
-- Name: group_maincro; Type: TABLE; Schema: public; Owner: ngd_master_user
--

CREATE TABLE public.group_maincro (
    id integer NOT NULL,
    "groupcroId" integer NOT NULL,
    "maincroId" integer NOT NULL
);


ALTER TABLE public.group_maincro OWNER TO ngd_master_user;

--
-- Name: group_maincro_id_seq; Type: SEQUENCE; Schema: public; Owner: ngd_master_user
--

CREATE SEQUENCE public.group_maincro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.group_maincro_id_seq OWNER TO ngd_master_user;

--
-- Name: group_maincro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ngd_master_user
--

ALTER SEQUENCE public.group_maincro_id_seq OWNED BY public.group_maincro.id;


--
-- Name: hotel; Type: TABLE; Schema: public; Owner: ngd_master_user
--

CREATE TABLE public.hotel (
    id integer NOT NULL,
    "codeHotel" character varying NOT NULL,
    "maincroSubcroId" integer
);


ALTER TABLE public.hotel OWNER TO ngd_master_user;

--
-- Name: hotel_id_seq; Type: SEQUENCE; Schema: public; Owner: ngd_master_user
--

CREATE SEQUENCE public.hotel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hotel_id_seq OWNER TO ngd_master_user;

--
-- Name: hotel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ngd_master_user
--

ALTER SEQUENCE public.hotel_id_seq OWNED BY public.hotel.id;


--
-- Name: maincro; Type: TABLE; Schema: public; Owner: ngd_master_user
--

CREATE TABLE public.maincro (
    id integer NOT NULL,
    maincro character varying NOT NULL
);


ALTER TABLE public.maincro OWNER TO ngd_master_user;

--
-- Name: subcro; Type: TABLE; Schema: public; Owner: ngd_master_user
--

CREATE TABLE public.subcro (
    id integer NOT NULL,
    subcro character varying NOT NULL,
    label character varying,
    flagcro integer,
    webcallback integer
);


ALTER TABLE public.subcro OWNER TO ngd_master_user;

--
-- Name: maincro_subcro_id_seq; Type: SEQUENCE; Schema: public; Owner: ngd_master_user
--

CREATE SEQUENCE public.maincro_subcro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maincro_subcro_id_seq OWNER TO ngd_master_user;

--
-- Name: maincro_subcro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ngd_master_user
--

ALTER SEQUENCE public.maincro_subcro_id_seq OWNED BY public.subcro.id;


--
-- Name: maincro_subcro; Type: TABLE; Schema: public; Owner: ngd_master_user
--

CREATE TABLE public.maincro_subcro (
    id integer DEFAULT nextval('public.maincro_subcro_id_seq'::regclass) NOT NULL,
    "maincroId" integer,
    "subcroId" integer NOT NULL
);


ALTER TABLE public.maincro_subcro OWNER TO ngd_master_user;

--
-- Name: hotel_vw; Type: VIEW; Schema: public; Owner: ngd_master_user
--

CREATE VIEW public.hotel_vw AS
 SELECT h.id,
    h."codeHotel",
    h."maincroSubcroId",
    s.subcro,
    m.maincro
   FROM (((public.hotel h
     JOIN public.maincro_subcro ms ON ((h."maincroSubcroId" = ms.id)))
     JOIN public.subcro s ON ((s.id = ms."subcroId")))
     LEFT JOIN public.maincro m ON ((m.id = ms."maincroId")))
  GROUP BY h.id, h."codeHotel", h."maincroSubcroId", s.subcro, m.maincro
  ORDER BY h."codeHotel";


ALTER VIEW public.hotel_vw OWNER TO ngd_master_user;

--
-- Name: maincro_id_seq; Type: SEQUENCE; Schema: public; Owner: ngd_master_user
--

CREATE SEQUENCE public.maincro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maincro_id_seq OWNER TO ngd_master_user;

--
-- Name: maincro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ngd_master_user
--

ALTER SEQUENCE public.maincro_id_seq OWNED BY public.maincro.id;


--
-- Name: maincro_vw; Type: VIEW; Schema: public; Owner: ngd_master_user
--

CREATE VIEW public.maincro_vw AS
 SELECT m.id,
    m.maincro,
    s.subcro
   FROM ((public.maincro m
     LEFT JOIN public.maincro_subcro ms ON ((ms."maincroId" = m.id)))
     LEFT JOIN public.subcro s ON ((ms."subcroId" = s.id)))
  ORDER BY m.maincro;


ALTER VIEW public.maincro_vw OWNER TO ngd_master_user;

--
-- Name: subcro_id_seq; Type: SEQUENCE; Schema: public; Owner: ngd_master_user
--

CREATE SEQUENCE public.subcro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subcro_id_seq OWNER TO ngd_master_user;

--
-- Name: subcro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ngd_master_user
--

ALTER SEQUENCE public.subcro_id_seq OWNED BY public.subcro.id;


--
-- Name: subcro_vw; Type: VIEW; Schema: public; Owner: ngd_master_user
--

CREATE VIEW public.subcro_vw AS
 SELECT s.id,
    m.maincro,
    s.subcro,
    s.label,
    s.flagcro,
    s.webcallback
   FROM ((public.subcro s
     LEFT JOIN public.maincro_subcro ms ON ((s.id = ms."subcroId")))
     LEFT JOIN public.maincro m ON ((ms."maincroId" = m.id)))
  ORDER BY m.maincro, s.subcro;


ALTER VIEW public.subcro_vw OWNER TO ngd_master_user;

--
-- Name: agent id; Type: DEFAULT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.agent ALTER COLUMN id SET DEFAULT nextval('public.agent_id_seq'::regclass);


--
-- Name: group_maincro id; Type: DEFAULT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.group_maincro ALTER COLUMN id SET DEFAULT nextval('public.group_maincro_id_seq'::regclass);


--
-- Name: hotel id; Type: DEFAULT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.hotel ALTER COLUMN id SET DEFAULT nextval('public.hotel_id_seq'::regclass);


--
-- Name: maincro id; Type: DEFAULT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.maincro ALTER COLUMN id SET DEFAULT nextval('public.maincro_id_seq'::regclass);


--
-- Name: subcro id; Type: DEFAULT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.subcro ALTER COLUMN id SET DEFAULT nextval('public.subcro_id_seq'::regclass);


--
-- Data for Name: agent; Type: TABLE DATA; Schema: public; Owner: ngd_master_user
--

COPY public.agent (id, "emailAddress", "firstName", "lastName", "groupcroId") FROM stdin;
\.
COPY public.agent (id, "emailAddress", "firstName", "lastName", "groupcroId") FROM '$$PATH$$/3502.dat';

--
-- Data for Name: agent_subcro; Type: TABLE DATA; Schema: public; Owner: ngd_master_user
--

COPY public.agent_subcro (id, "agentId", "maincroSubcroId") FROM stdin;
\.
COPY public.agent_subcro (id, "agentId", "maincroSubcroId") FROM '$$PATH$$/3506.dat';

--
-- Data for Name: groupCro; Type: TABLE DATA; Schema: public; Owner: ngd_master_user
--

COPY public."groupCro" (id, name) FROM stdin;
\.
COPY public."groupCro" (id, name) FROM '$$PATH$$/3508.dat';

--
-- Data for Name: group_maincro; Type: TABLE DATA; Schema: public; Owner: ngd_master_user
--

COPY public.group_maincro (id, "groupcroId", "maincroId") FROM stdin;
\.
COPY public.group_maincro (id, "groupcroId", "maincroId") FROM '$$PATH$$/3509.dat';

--
-- Data for Name: hotel; Type: TABLE DATA; Schema: public; Owner: ngd_master_user
--

COPY public.hotel (id, "codeHotel", "maincroSubcroId") FROM stdin;
\.
COPY public.hotel (id, "codeHotel", "maincroSubcroId") FROM '$$PATH$$/3511.dat';

--
-- Data for Name: maincro; Type: TABLE DATA; Schema: public; Owner: ngd_master_user
--

COPY public.maincro (id, maincro) FROM stdin;
\.
COPY public.maincro (id, maincro) FROM '$$PATH$$/3513.dat';

--
-- Data for Name: maincro_subcro; Type: TABLE DATA; Schema: public; Owner: ngd_master_user
--

COPY public.maincro_subcro (id, "maincroId", "subcroId") FROM stdin;
\.
COPY public.maincro_subcro (id, "maincroId", "subcroId") FROM '$$PATH$$/3516.dat';

--
-- Data for Name: subcro; Type: TABLE DATA; Schema: public; Owner: ngd_master_user
--

COPY public.subcro (id, subcro, label, flagcro, webcallback) FROM stdin;
\.
COPY public.subcro (id, subcro, label, flagcro, webcallback) FROM '$$PATH$$/3514.dat';

--
-- Name: agent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ngd_master_user
--

SELECT pg_catalog.setval('public.agent_id_seq', 7, true);


--
-- Name: agent_maincro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ngd_master_user
--

SELECT pg_catalog.setval('public.agent_maincro_id_seq', 1, false);


--
-- Name: agent_subcro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ngd_master_user
--

SELECT pg_catalog.setval('public.agent_subcro_id_seq', 12, true);


--
-- Name: group_maincro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ngd_master_user
--

SELECT pg_catalog.setval('public.group_maincro_id_seq', 17, true);


--
-- Name: groupcro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ngd_master_user
--

SELECT pg_catalog.setval('public.groupcro_id_seq', 4, true);


--
-- Name: hotel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ngd_master_user
--

SELECT pg_catalog.setval('public.hotel_id_seq', 21, true);


--
-- Name: maincro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ngd_master_user
--

SELECT pg_catalog.setval('public.maincro_id_seq', 11, true);


--
-- Name: maincro_subcro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ngd_master_user
--

SELECT pg_catalog.setval('public.maincro_subcro_id_seq', 269, true);


--
-- Name: subcro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ngd_master_user
--

SELECT pg_catalog.setval('public.subcro_id_seq', 171, true);


--
-- Name: agent agent_pkey; Type: CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.agent
    ADD CONSTRAINT agent_pkey PRIMARY KEY (id);


--
-- Name: agent_subcro agent_subcro_pkey; Type: CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.agent_subcro
    ADD CONSTRAINT agent_subcro_pkey PRIMARY KEY (id);


--
-- Name: group_maincro group_maincro_pkey; Type: CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.group_maincro
    ADD CONSTRAINT group_maincro_pkey PRIMARY KEY (id);


--
-- Name: groupCro groupcro_pkey; Type: CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public."groupCro"
    ADD CONSTRAINT groupcro_pkey PRIMARY KEY (id);


--
-- Name: hotel hotel_pkey; Type: CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.hotel
    ADD CONSTRAINT hotel_pkey PRIMARY KEY (id);


--
-- Name: maincro maincro_pkey; Type: CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.maincro
    ADD CONSTRAINT maincro_pkey PRIMARY KEY (id);


--
-- Name: maincro_subcro maincro_subcro_pkey; Type: CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.maincro_subcro
    ADD CONSTRAINT maincro_subcro_pkey PRIMARY KEY (id);


--
-- Name: subcro subcro_pkey; Type: CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.subcro
    ADD CONSTRAINT subcro_pkey PRIMARY KEY (id);


--
-- Name: agent_id_ix; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX agent_id_ix ON public.agent USING btree (id);


--
-- Name: agent_idx; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE UNIQUE INDEX agent_idx ON public.agent_subcro USING btree ("agentId", "maincroSubcroId");


--
-- Name: agent_subcro_id_ix; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX agent_subcro_id_ix ON public.agent_subcro USING btree (id);


--
-- Name: codehotel_idx; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE UNIQUE INDEX codehotel_idx ON public.hotel USING btree ("codeHotel");


--
-- Name: emailaddress_idx; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE UNIQUE INDEX emailaddress_idx ON public.agent USING btree ("emailAddress");


--
-- Name: gm_idx; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE UNIQUE INDEX gm_idx ON public.group_maincro USING btree ("groupcroId", "maincroId");


--
-- Name: groupCro_id_ix; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX "groupCro_id_ix" ON public."groupCro" USING btree (id);


--
-- Name: group_maincro_id_ix; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX group_maincro_id_ix ON public.group_maincro USING btree (id);


--
-- Name: groupcroId_ix; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX "groupcroId_ix" ON public.agent USING btree ("groupcroId");


--
-- Name: hotel_id_idx; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX hotel_id_idx ON public.hotel USING btree (id);


--
-- Name: hotel_id_ix; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX hotel_id_ix ON public.hotel USING btree (id);


--
-- Name: maincroSubcroId_ix; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX "maincroSubcroId_ix" ON public.hotel USING btree ("maincroSubcroId");


--
-- Name: maincro_id_ix; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX maincro_id_ix ON public.maincro USING btree (id);


--
-- Name: maincro_idx; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE UNIQUE INDEX maincro_idx ON public.maincro USING btree (maincro);


--
-- Name: maincro_notnull_main_idx; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE UNIQUE INDEX maincro_notnull_main_idx ON public.maincro_subcro USING btree ("maincroId", "subcroId") WHERE ("maincroId" IS NOT NULL);


--
-- Name: maincro_null_main_idx; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE UNIQUE INDEX maincro_null_main_idx ON public.maincro_subcro USING btree ("subcroId") WHERE ("maincroId" IS NULL);


--
-- Name: maincro_subcro_id_ix; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX maincro_subcro_id_ix ON public.maincro_subcro USING btree (id);


--
-- Name: name_idx; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE UNIQUE INDEX name_idx ON public."groupCro" USING btree (name);


--
-- Name: subcro_id_ix; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE INDEX subcro_id_ix ON public.subcro USING btree (id);


--
-- Name: subcro_idx; Type: INDEX; Schema: public; Owner: ngd_master_user
--

CREATE UNIQUE INDEX subcro_idx ON public.subcro USING btree (subcro);


--
-- Name: agent_subcro agent_fk; Type: FK CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.agent_subcro
    ADD CONSTRAINT agent_fk FOREIGN KEY ("agentId") REFERENCES public.agent(id);


--
-- Name: group_maincro group_fk; Type: FK CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.group_maincro
    ADD CONSTRAINT group_fk FOREIGN KEY ("groupcroId") REFERENCES public."groupCro"(id) NOT VALID;


--
-- Name: agent groupcro_fk; Type: FK CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.agent
    ADD CONSTRAINT groupcro_fk FOREIGN KEY ("groupcroId") REFERENCES public."groupCro"(id) NOT VALID;


--
-- Name: hotel maincroSubcro_fk; Type: FK CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.hotel
    ADD CONSTRAINT "maincroSubcro_fk" FOREIGN KEY ("maincroSubcroId") REFERENCES public.maincro_subcro(id) NOT VALID;


--
-- Name: agent_subcro maincroSubcro_fk; Type: FK CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.agent_subcro
    ADD CONSTRAINT "maincroSubcro_fk" FOREIGN KEY ("maincroSubcroId") REFERENCES public.maincro_subcro(id);


--
-- Name: group_maincro maincro_fk; Type: FK CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.group_maincro
    ADD CONSTRAINT maincro_fk FOREIGN KEY ("maincroId") REFERENCES public.maincro(id) NOT VALID;


--
-- Name: maincro_subcro maincro_fk; Type: FK CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.maincro_subcro
    ADD CONSTRAINT maincro_fk FOREIGN KEY ("maincroId") REFERENCES public.maincro(id);


--
-- Name: maincro_subcro subcro_fk; Type: FK CONSTRAINT; Schema: public; Owner: ngd_master_user
--

ALTER TABLE ONLY public.maincro_subcro
    ADD CONSTRAINT subcro_fk FOREIGN KEY ("subcroId") REFERENCES public.subcro(id);


--
-- Name: DATABASE "Accor"; Type: ACL; Schema: -; Owner: ngd_master_user
--

GRANT CONNECT ON DATABASE "Accor" TO ngd_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO ngd_user;


--
-- Name: TABLE agent; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public.agent TO ngd_user;


--
-- Name: TABLE agent_subcro; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public.agent_subcro TO ngd_user;


--
-- Name: TABLE "groupCro"; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public."groupCro" TO ngd_user;


--
-- Name: TABLE group_maincro; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public.group_maincro TO ngd_user;


--
-- Name: TABLE hotel; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public.hotel TO ngd_user;


--
-- Name: TABLE maincro; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public.maincro TO ngd_user;


--
-- Name: TABLE subcro; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public.subcro TO ngd_user;


--
-- Name: TABLE maincro_subcro; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public.maincro_subcro TO ngd_user;


--
-- Name: TABLE hotel_vw; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public.hotel_vw TO ngd_user;


--
-- Name: TABLE maincro_vw; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public.maincro_vw TO ngd_user;


--
-- Name: TABLE subcro_vw; Type: ACL; Schema: public; Owner: ngd_master_user
--

GRANT SELECT ON TABLE public.subcro_vw TO ngd_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT ON TABLES TO ngd_user;


--
-- PostgreSQL database dump complete
--

